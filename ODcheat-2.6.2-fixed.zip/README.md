# ODcheat — Android game companion

ODcheat is an Android companion app built with Kotlin and Jetpack Compose. It includes a local profile manager, app launcher, file tools, settings and a selectable visual gallery.

## Gallery assets

Four supplied character renders are included as selectable in-app preview styles: Crimson Vanguard, Ruby Shadow, Silver Dragon and Frost Guardian. Selection is saved through DataStore. These images are gallery/profile artwork; they are not game-compatible character texture files and do not alter the OXIDE game model.

## Build

- Android SDK 35
- JDK 17
- Gradle 8.9

Run `gradle assembleDebug`. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`. GitHub Actions builds and uploads the APK artifact.

## Package

- App label: ODcheat
- Application ID: `com.odcheat.launcher`
- Source namespace remains `com.oxide.launcher` to preserve Kotlin package/resource references.

## Notes

The overlay is a companion UI. The project does not have an official game SDK or a feed for game character data, so gallery selection remains inside the app and cannot apply a skin to the remote game character.
